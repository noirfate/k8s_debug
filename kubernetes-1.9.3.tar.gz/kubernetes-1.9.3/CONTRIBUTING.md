# Contributing

Information about contributing to the
[kubernetes code repo](README.md) lives in the
[kubernetes community repo](https://github.com/kubernetes/community)
(it's a big topic).


[![Analytics](https://kubernetes-site.appspot.com/UA-36037335-10/GitHub/CONTRIBUTING.md?pixel)]()

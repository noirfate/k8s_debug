"""
Target Commands
"""


def retrieve(args):
    pass


def create(args):
    pass


def start(args):
    pass


def stop(args):
    pass


def delete(args):
    pass


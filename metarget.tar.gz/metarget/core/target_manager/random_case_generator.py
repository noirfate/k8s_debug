"""

"""

class RandomCaseGenerator:
    pass